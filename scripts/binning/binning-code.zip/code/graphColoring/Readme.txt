This is a modification to code from Shalin Shah to perform vertex coloring in a balanced manner. See Readme-shah.txt for more info. 

Balanced vertex coloring is achieved by modifying Brelaz algorithm so that each point is always added to the smallest bin possible. 
